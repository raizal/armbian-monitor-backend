/root/ccminer/ccminer -a verus -o stratum+tcp://ap.luckpool.net:3956 -u RNZDrcf97tBDwWtCURFpBbexPaCR5evyuu.$WORKER_NAME -p x -t 4 > /root/mining.log
